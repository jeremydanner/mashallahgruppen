<?php
/*
*   Author @ https://HandelsMarketing.se
*
*   (c) Mashallahgruppen
*
*/
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">

      <meta name="author" content="Jeremy Danner">

      <link rel="icon" href="#"><!-- Add your bookmark icon hear -->
      <link href="" rel="stylesheet">

      <title>Site Title</title>
  </head>

  <body>
      <h1>Woops!</h1>
      <a href="/">go home</a>

  </body>
</html>
